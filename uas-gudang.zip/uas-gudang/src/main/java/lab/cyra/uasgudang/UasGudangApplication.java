package lab.cyra.uasgudang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UasGudangApplication {

	public static void main(String[] args) {
		SpringApplication.run(UasGudangApplication.class, args);
	}
}
