/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.cyra.uasgudang.repo;

import lab.cyra.uasgudang.entity.Gudang;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


/**
 *
 * @author Toshiba
 */
@Repository
public interface GudangRepo extends JpaRepository<Gudang, Integer> {
    
}
