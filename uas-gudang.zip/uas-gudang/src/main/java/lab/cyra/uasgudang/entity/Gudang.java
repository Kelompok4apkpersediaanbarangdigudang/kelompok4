/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab.cyra.uasgudang.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Toshiba
 */
@Entity
public class Gudang {
    @Id @Getter @Setter
    private int id;
    @Getter @Setter
    private String jenis;
    @Getter @Setter
    private String nama_barang;
}
