gudangApp.controller('DaftarController', 
    function($scope, $http, $window, $location) {
        $scope.daftarGudang = [];

        $scope.updateDaftar = function() {
            $http.get("/get-home").then(sukses, gagal);

            function sukses(response) {
                $scope.daftarGudang = response.data;
            }

            function gagal(response) {}
        };

        $scope.tambah = function() {
            $window.location.href = "/tambah-ui";
            //$location.path('/tambah-ui');
        }

        $scope.edit = function(gudang) {
            $window.location.href = "/edit-ui?id=" + gudang.id +
                    "&jenis=" + gudang.jenis +
                    "&nama_barang=" + gudang.nama_barang;
        };

        $scope.delete = function(gudang) {
            $http.delete("/api/delete/" + gudang.id).then(sukses, gagal);

            function sukses(response) {
                $scope.updateDaftar();
            }

            function gagal(response) {}
        };

        $scope.updateDaftar();
    }
);